package com.mycompany.reservationsystem;

import org.junit.Before;
import org.junit.Test;

import java.lang.reflect.Method;

import static org.junit.Assert.*;

public class ReservationSystemTest {

    private ReservationSystem system;

    @Before
    public void setUp() {
        system = new ReservationSystem();
    }

    @Test
    public void testAddReservation_UsingReflection() throws Exception {
        // Create a reservation
        ReservationSystem.Reservation r =
                new ReservationSystem.Reservation("2025-09-07", 1, "John Doe", 4);

        // Access private method addReservation
        Method addMethod = ReservationSystem.class.getDeclaredMethod("addReservation", ReservationSystem.Reservation.class);
        addMethod.setAccessible(true);

        boolean result = (boolean) addMethod.invoke(system, r);
        assertTrue("Reservation should be added successfully", result);
    }

    @Test
    public void testDeleteReservation_UsingReflection() throws Exception {
        // Add reservation first
        Method addMethod = ReservationSystem.class.getDeclaredMethod("addReservation", ReservationSystem.Reservation.class);
        addMethod.setAccessible(true);
        ReservationSystem.Reservation r =
                new ReservationSystem.Reservation("2025-09-07", 2, "Jane Doe", 3);
        addMethod.invoke(system, r);

        // Delete reservation
        Method deleteMethod = ReservationSystem.class.getDeclaredMethod("deleteReservation", String.class);
        deleteMethod.setAccessible(true);

        boolean result = (boolean) deleteMethod.invoke(system, "Jane Doe");
        assertTrue("Reservation should be deleted successfully", result);
    }

    @Test
    public void testDeleteReservation_NotFound() throws Exception {
        Method deleteMethod = ReservationSystem.class.getDeclaredMethod("deleteReservation", String.class);
        deleteMethod.setAccessible(true);

        boolean result = (boolean) deleteMethod.invoke(system, "Unknown Customer");
        assertFalse("Deleting non-existent reservation should return false", result);
    }

    @Test
    public void testAddReservation_FailsWhenFull() throws Exception {
        Method addMethod = ReservationSystem.class.getDeclaredMethod("addReservation", ReservationSystem.Reservation.class);
        addMethod.setAccessible(true);

        // Fill all 10 slots
        for (int i = 0; i < 10; i++) {
            ReservationSystem.Reservation r =
                    new ReservationSystem.Reservation("2025-09-07", i + 1, "Customer" + i, 2);
            addMethod.invoke(system, r);
        }

        // Attempt to add the 11th reservation
        ReservationSystem.Reservation extra =
                new ReservationSystem.Reservation("2025-09-08", 11, "Extra", 3);
        boolean result = (boolean) addMethod.invoke(system, extra);

        assertFalse("Reservation should fail when array is full", result);
    }
}